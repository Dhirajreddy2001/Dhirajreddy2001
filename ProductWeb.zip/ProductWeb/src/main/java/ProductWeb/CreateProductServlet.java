package ProductWeb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import product.productservice.BO.ProductBO;
import product.productservice.BO.ProductBOimpl;

import product.productservices.dto.Product;

/**
 * Servlet implementation class CreateProductServlet
 */

public class CreateProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		      Integer id=Integer.parseInt(request.getParameter("id"));
		      String name=request.getParameter("name");
		      String descString=request.getParameter("desc");
		      Integer price=Integer.parseInt(request.getParameter("price"));
		      Product product=new Product();
		      product.setId(id);
		      product.setName(name);
		      product.setDescription(descString);
		      product.setPrice(price);
		      
		    ProductBO BO = new ProductBOimpl();
		    BO.create(product);
		    PrintWriter writer = response.getWriter();
		    writer.print("Product Created !!!!!");
		    
		
	}

}
