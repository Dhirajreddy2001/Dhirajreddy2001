package ProductWeb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import product.productservice.BO.ProductBO;
import product.productservice.BO.ProductBOimpl;

import product.productservices.dto.Product;

/**
 * Servlet implementation class DisplayProductDetailsServlet
 */
public class DisplayProductDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ProductBO bo=new ProductBOimpl();
		Product product=bo.findProduct(Integer.parseInt(request.getParameter("id")));
		PrintWriter outPrintWriter=response.getWriter();
		outPrintWriter.print("Product Details :");
		outPrintWriter.print("Product Id: "+product.getId());
		outPrintWriter.print("Product Name: "+product.getName());
		outPrintWriter.print("Product Description: "+product.getDescription());
		outPrintWriter.print("Product Price: "+product.getPrice());
		
	}

}
