package product.productservices.dao;






import static org.junit.Assert.*;

import org.junit.Test;

import product.productservices.dto.Product;

public class ProductDAOimplTest {

	@Test
	public void createshouldCreateAProduct() {
		ProductDAO dao=new ProductDAOimpl();
		Product product=new Product();
		product.setId(1);
		product.setName("Iphone");
		product.setDescription("Apple USA");
		product.setPrice(500);
		dao.create(product);
		Product resultProduct=dao.read(1);
		
		assertNotNull(resultProduct);
		
        assertEquals("Iphone", resultProduct.getName());
		
	}

}
