package product.productservices.dao;

import java.util.HashMap;
import java.util.Map;

import product.productservices.dto.Product;

public class ProductDAOimpl implements ProductDAO {

	Map<Integer,Product> productsMap=new HashMap<Integer, Product>();
	public void create(Product product) {
		// TODO Auto-generated method stub
		productsMap.put(product.getId(), product);
		

	}

  public Product read(int id) {
		// TODO Auto-generated method stub
		return productsMap.get(id);
	  

	}

	public void update(Product product) {
		// TODO Auto-generated method stub

	}

	public void delete(int id) {
		// TODO Auto-generated method stub

	}

}
