package product.productservices.dao;

import product.productservices.dto.Product;

public interface ProductDAO {
	void create(Product produtProduct);
	Product read(int id);
	void update(Product product);
	void delete(int id);

}
