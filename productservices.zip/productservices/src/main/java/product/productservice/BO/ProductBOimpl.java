package product.productservice.BO;

import product.productservices.dto.Product;

public class ProductBOimpl implements ProductBO {

	@Override
	public void create(Product product) {
		// TODO Auto-generated method stub

	}

	@Override
	public Product findProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
